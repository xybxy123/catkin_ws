//摄像头识别yolo
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>

using namespace cv;
using namespace std;

std::string modelFile = "/home/xybxy/catkin_ws/src/opencv_test/src/best.onnx";
cv::dnn::Net net;  // 先声明，在Yolo_Init中初始化
VideoCapture cap;  // 先声明，在Cap_Init中初始化

void Yolo_Init();
void Cap_Init();

int main() {
    Yolo_Init();
    Cap_Init();  // 若摄像头打开失败，会在此处退出程序

    // 获取摄像头分辨率
    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
    cout << "摄像头分辨率: " << width << "x" << height << endl;

    // 创建窗口（只需创建一次，无需在循环中重复创建）
    namedWindow("摄像头预览", WINDOW_NORMAL);
    namedWindow("Detection Result", WINDOW_NORMAL);

    Mat frame;
    int frameCount = 0;

    cout << "按 's' 保存当前帧，按 'q' 退出" << endl;

    while (true) {
        cap >> frame;
        // 检查是否读取到有效帧
        if (frame.empty()) {
            cerr << "ERROR: 无法获取帧，摄像头可能已断开" << endl;
            break;
        }

        // 显示原始帧
        imshow("摄像头预览", frame);
        
        // 保存原图副本用于绘制
        cv::Mat img_with_detections = frame.clone();

        // 图像预处理
        cv::Mat blob = cv::dnn::blobFromImage(
            frame, 
            1.0 / 255.0,
            cv::Size(640, 640),
            cv::Scalar(0, 0, 0),
            true,
            false
        );

        // 模型推理
        net.setInput(blob);
        cv::Mat output = net.forward();

        // 解析输出
        cv::Mat detections = output.reshape(1, output.size[1]);

        // 配置参数
        float confThreshold = 0.5;
        std::vector<std::string> classNames = {"class1", "class2"};  // 替换为实际类别名称
        int imgWidth = frame.cols;
        int imgHeight = frame.rows;
        float scaleW = (float)imgWidth / 640;
        float scaleH = (float)imgHeight / 640;

        // 遍历检测框并绘制
        for (int i = 0; i < detections.rows; i++) {
            const float* data = detections.ptr<float>(i);
            
            float x = data[0] * scaleW;
            float y = data[1] * scaleH;
            float w = data[2] * scaleW;
            float h = data[3] * scaleH;
            float objConf = data[4];
            float class1Conf = data[5];
            float class2Conf = data[6];

            if (objConf > confThreshold) {
                float maxClassConf = std::max(class1Conf, class2Conf);
                int classId = (maxClassConf == class1Conf) ? 0 : 1;

                int left = static_cast<int>(x - w / 2);
                int top = static_cast<int>(y - h / 2);
                int right = static_cast<int>(x + w / 2);
                int bottom = static_cast<int>(y + h / 2);

                left = std::max(0, std::min(left, imgWidth - 1));
                top = std::max(0, std::min(top, imgHeight - 1));
                right = std::max(0, std::min(right, imgWidth - 1));
                bottom = std::max(0, std::min(bottom, imgHeight - 1));

                cv::rectangle(img_with_detections, cv::Point(left, top), cv::Point(right, bottom), cv::Scalar(0, 255, 0), 2);

                std::string label = classNames[classId] + " : " + 
                                   std::to_string(static_cast<int>(maxClassConf * 100)) + "%";
                int baseLine;
                cv::Size labelSize = cv::getTextSize(label, cv::FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
                cv::rectangle(img_with_detections,
                              cv::Point(left, top - labelSize.height),
                              cv::Point(left + labelSize.width, top + baseLine),
                              cv::Scalar(0, 255, 0), cv::FILLED);
                cv::putText(img_with_detections, label, cv::Point(left, top),
                           cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 0), 1);
            }
        }

        // 显示检测结果
        cv::imshow("Detection Result", img_with_detections);

        // 按键处理
        char key = waitKey(30);
        if (key == 's' || key == 'S') {
            string filename = "frame_" + to_string(frameCount++) + ".jpg";
            if (imwrite(filename, frame)) {
                cout << "已保存帧: " << filename << endl;
            } else {
                cerr << "ERROR: 保存帧失败" << endl;
            }
        }
        if (key == 'q' || key == 'Q' || key == 27) {
            break;
        }
    }

    // 释放资源
    cap.release();
    destroyAllWindows();
    return 0;
}

void Yolo_Init()
{
    net = cv::dnn::readNetFromONNX(modelFile);  // 在初始化函数中加载模型
    if (net.empty()) {
        std::cerr << "Failed to load network!" << std::endl;
        exit(-1);  // 模型加载失败，退出程序
    } else {
        cout << "load network successfully!" << endl;
    }
}

void Cap_Init()
{
    // 尝试打开摄像头（可修改索引0/1/2）
    cap.open(2);  // 优先尝试索引0
    
}
