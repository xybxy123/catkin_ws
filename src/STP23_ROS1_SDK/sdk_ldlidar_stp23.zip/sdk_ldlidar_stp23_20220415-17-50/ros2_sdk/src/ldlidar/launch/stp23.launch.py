#!/usr/bin/env python3
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
  return LaunchDescription([
    Node(
      package='ldlidar',
      executable='ldlidar',
      name='STP23',
      output='screen',
      parameters=[
        {'product_name': 'LDLiDAR_STP23'},
        {'topic_name': 'single_laser'},
        {'port_name': '/dev/ttyUSB0'},
        {'frame_id': 'base_laser'}
      ]
    ),
    Node(
      package='tf2_ros',
      executable='static_transform_publisher',
      arguments= ['0','0','0.18','0','0','0','world','base_laser']
    )
  ])