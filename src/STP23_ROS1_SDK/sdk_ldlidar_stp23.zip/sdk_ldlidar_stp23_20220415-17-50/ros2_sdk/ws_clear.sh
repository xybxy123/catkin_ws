#! /bin/bash
#Author: David Hu
#Date: 2022-02
rm -rf ./build
echo "del build floder"
rm -rf ./install
echo "del install floder"
rm -rf ./log
echo "del log floder"
echo "del is ok....."